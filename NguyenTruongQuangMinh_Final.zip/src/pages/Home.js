import React, { Component } from "react";
class Home extends Component {
  state = {};
  render() {
    return (
      <div className="container">
        <h1 className="text-center mt-5">Welcome to Admin side</h1>
      </div>
    );
  }
}

export default Home;
