import Home from "./pages/Home";
import Instructors from "./pages/Instructors";
const routes = [
  { path: "", element: <Home /> },
  { path: "/home", element: <Home /> },
  { path: "/instructors", element: <Instructors /> },
];
export default routes;
